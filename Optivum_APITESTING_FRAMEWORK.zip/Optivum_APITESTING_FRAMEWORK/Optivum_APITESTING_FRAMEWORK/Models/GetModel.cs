﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Optivum_APITESTING_FRAMEWORK.Models
{
    public class Datum
    {
        public string id { get; set; }
        public string employee_name { get; set; }
        public string employee_salary { get; set; }
        public string employee_age { get; set; }
        public string profile_image { get; set; }

    }

    public class EmployeeModel
    {
        public string status { get; set; }
        public List<Datum> data { get; set; }

    }
}
