﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Optivum_APITESTING_FRAMEWORK.Utilities.Models
{
    public class RequestModel
    {
        public string method { get; set; }
        public string contentType { get; set; }
        public string endPoint { get; set; }
        public string token { get; set; }
        public string transactionID { get; set; }
        public string sessionID { get; set; }
        public string content { get; set; }
    }
}
