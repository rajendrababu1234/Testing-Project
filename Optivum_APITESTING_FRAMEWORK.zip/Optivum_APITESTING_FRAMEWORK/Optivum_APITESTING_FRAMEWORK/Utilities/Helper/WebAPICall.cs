﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using Optivum_APITESTING_FRAMEWORK.Utilities.Models;

namespace Optivum_APITESTING_FRAMEWORK.Utilities.Helper
{
   public class WebAPICall
    {
        public static WebRequest GetRequest(RequestModel model)
        {
            var request = WebRequest.Create(model.endPoint);
            request.Method = model.method;
            request.ContentType = model.contentType;

            if (model.token != null)
            {
                request.Headers.Add("Authorization-Token", model.token);
            }
            if (model.transactionID != null)
            {
                request.Headers.Add("TransactionID", model.transactionID);
            }
            if (model.sessionID != null)
            {
                request.Headers.Add("SessionID", model.sessionID);
            }

            else
            if (model.content != null)
            {
                var dataArray = Encoding.UTF8.GetBytes(model.content.ToString());
                request.ContentLength = dataArray.Length;
                var requestStream = request.GetRequestStream();
                requestStream.Write(dataArray, 0, dataArray.Length);
                requestStream.Flush();
                requestStream.Close();
            }

            return request;
        }

        public static string UnPack(WebResponse response)
        {
            var dataStream = response.GetResponseStream();
            var reader = new StreamReader(dataStream);
            return reader.ReadToEnd();
        }
    }
}
